/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csc668assignment1.Resources;

/**
 *
 * @author axelanconaesselmann
 */
public interface MessageResourceInterface {
    public void printAlertMessage(String alertMessage);
    public void printMessage(String message);
}
