/*
 * Only a stub for now
 */
package csc668assignment1.UserInterface;

/**
 *
 * @author axelanconaesselmann
 */
public class GuiUserInterface extends UserInterface {
    public GuiUserInterface() {
        throw new UnsupportedOperationException("GUI is not supported yet.");
    }
}
